from __future__ import annotations

from ...models.history.entities import (
    HistoryBatch,
    HistoryPage,
    HistoryRenderPageOcrText,
)
from ...models.history.schemas import (
    BatchCreateRequest,
    BatchJianpuTextUpdate,
    BatchListItem,
    BatchPageOrderRequest,
    BatchRenderPageOcrTextsUpdate,
    BatchRenderPagesUpdate,
    BatchResponse,
    DeleteAllResponse,
    PageResponse,
    PageUpdate,
    RenderPageOcrText,
)
from ...services.history.history_service import HistoryService


class HistoryActions:
    def __init__(self, service: HistoryService | None = None) -> None:
        self.service = service or HistoryService()

    def list_history(self) -> list[BatchListItem]:
        return [
            BatchListItem(
                id=batch.id,
                created_at=batch.created_at,
                page_count=batch.page_count,
                status=batch.status,
                first_file_name=batch.first_file_name,
                last_completed_at=batch.last_completed_at,
            )
            for batch in self.service.list_batch_summaries()
        ]

    def create_batch(self, req: BatchCreateRequest) -> BatchResponse:
        pages = [
            HistoryPage(
                input_file_name=p.input_file_name,
                input_file_id=p.input_file_id,
                task_id=p.task_id,
                musicxml_file_id=p.musicxml_file_id,
                jianpu_text=p.jianpu_text,
                ocr_text=p.ocr_text,
                text_attachments=p.text_attachments,
                svg_file_id=p.svg_file_id,
                engine_version=p.engine_version if p.svg_file_id else "",
                document_revision=p.document_revision or p.text_hash,
                overlay_svg_file_id=p.overlay_svg_file_id,
                overlay_file_id=p.overlay_file_id,
                source_map_file_id=p.source_map_file_id,
                text_hash=p.text_hash,
                text_anchors=p.text_anchors,
                status=p.status,
                error_message=p.error_message,
                omr_file_id=p.omr_file_id,
                original_musicxml=p.original_musicxml,
                working_musicxml=p.working_musicxml,
                deleted_source_ids=p.deleted_source_ids,
            )
            for p in req.pages
        ]
        return _batch_to_response(
            self.service.create_batch(
                pages,
                req.render_page_file_ids,
                jianpu_text=req.jianpu_text,
                render_page_ocr_texts=[
                    HistoryRenderPageOcrText(
                        page_index=item.page_index,
                        ocr_text=item.ocr_text,
                    )
                    for item in req.render_page_ocr_texts
                ],
                render_output_stale=req.render_output_stale,
            )
        )

    def get_history(self, batch_id: int) -> BatchResponse:
        batch = self.service.get_batch(batch_id)
        if not batch:
            raise FileNotFoundError("Batch not found")
        return _batch_to_response(batch)

    def get_history_page(self, page_id: int) -> PageResponse:
        page = self.service.get_page(page_id)
        if not page:
            raise FileNotFoundError("Page not found")
        return _page_to_response(page)

    def update_history_page(self, page_id: int, req: PageUpdate) -> PageResponse:
        page = self.service.update_page(
            page_id,
            task_id=req.task_id,
            musicxml_file_id=req.musicxml_file_id,
            jianpu_text=req.jianpu_text if req.jianpu_text is not None else None,
            ocr_text=req.ocr_text,
            text_attachments=req.text_attachments,
            svg_file_id=req.svg_file_id,
            engine_version=req.engine_version,
            document_revision=req.document_revision,
            overlay_svg_file_id=req.overlay_svg_file_id,
            overlay_file_id=req.overlay_file_id,
            source_map_file_id=req.source_map_file_id,
            text_hash=req.text_hash,
            text_anchors=req.text_anchors,
            status=req.status,
            error_message=req.error_message,
            omr_file_id=req.omr_file_id,
            original_musicxml=req.original_musicxml,
            working_musicxml=req.working_musicxml,
            deleted_source_ids=req.deleted_source_ids,
        )
        if not page:
            raise FileNotFoundError("Page not found")
        return _page_to_response(page)

    def update_batch_render_pages(
        self, batch_id: int, req: BatchRenderPagesUpdate
    ) -> BatchResponse:
        batch = self.service.update_batch_render_pages(
            batch_id,
            req.render_page_file_ids,
            render_output_stale=req.render_output_stale,
        )
        if not batch:
            raise FileNotFoundError("Batch not found")
        return _batch_to_response(batch)

    def update_batch_jianpu_text(
        self, batch_id: int, req: BatchJianpuTextUpdate
    ) -> BatchResponse:
        batch = self.service.update_batch_jianpu_text(batch_id, req.jianpu_text)
        if not batch:
            raise FileNotFoundError("Batch not found")
        return _batch_to_response(batch)

    def update_batch_render_page_ocr_texts(
        self, batch_id: int, req: BatchRenderPageOcrTextsUpdate
    ) -> BatchResponse:
        batch = self.service.update_batch_render_page_ocr_texts(
            batch_id,
            [
                HistoryRenderPageOcrText(
                    page_index=item.page_index,
                    ocr_text=item.ocr_text,
                )
                for item in req.pages
            ],
            render_output_stale=req.render_output_stale,
        )
        if not batch:
            raise FileNotFoundError("Batch not found")
        return _batch_to_response(batch)

    def reorder_pages(self, batch_id: int, req: BatchPageOrderRequest) -> BatchResponse:
        page_orders = [(item.page_id, item.jianpu_text) for item in req.pages]
        batch = self.service.reorder_pages(batch_id, req.jianpu_text, page_orders)
        if not batch:
            raise FileNotFoundError("Batch not found")
        return _batch_to_response(batch)

    def delete_history(self, batch_id: int) -> dict[str, bool]:
        if not self.service.delete_batch(batch_id):
            raise FileNotFoundError("Batch not found")
        return {"ok": True}

    def delete_all_history(self) -> DeleteAllResponse:
        return DeleteAllResponse(deleted_count=self.service.delete_all())


def _page_to_response(page: HistoryPage) -> PageResponse:
    return PageResponse(
        id=page.id,
        batch_id=page.batch_id,
        input_file_name=page.input_file_name,
        input_file_id=page.input_file_id,
        task_id=page.task_id,
        musicxml_file_id=page.musicxml_file_id,
        jianpu_text=page.jianpu_text,
        ocr_text=page.ocr_text,
        text_attachments=page.text_attachments,
        svg_file_id=page.svg_file_id,
        engine_version=page.engine_version,
        document_revision=page.document_revision,
        overlay_svg_file_id=page.overlay_svg_file_id,
        overlay_file_id=page.overlay_file_id,
        source_map_file_id=page.source_map_file_id,
        text_hash=page.text_hash,
        text_anchors=page.text_anchors,
        status=page.status,
        error_message=page.error_message,
        omr_file_id=page.omr_file_id,
        original_musicxml=page.original_musicxml,
        working_musicxml=page.working_musicxml,
        deleted_source_ids=page.deleted_source_ids,
    )


def _batch_to_response(batch: HistoryBatch) -> BatchResponse:
    return BatchResponse(
        id=batch.id,
        created_at=batch.created_at,
        page_count=batch.page_count,
        status=batch.status,
        jianpu_text=batch.jianpu_text,
        render_page_file_ids=_batch_render_page_file_ids(batch),
        engine_version=batch.engine_version,
        document_revision=batch.document_revision,
        render_page_ocr_texts=[
            RenderPageOcrText(
                page_index=item.page_index,
                ocr_text=item.ocr_text,
            )
            for item in batch.render_page_ocr_texts
        ],
        render_output_stale=batch.render_output_stale,
        pages=[_page_to_response(p) for p in batch.pages],
    )


def _batch_render_page_file_ids(batch: HistoryBatch) -> list[str]:
    if batch.render_page_file_ids:
        return batch.render_page_file_ids
    return [page.svg_file_id for page in batch.pages if page.svg_file_id]
