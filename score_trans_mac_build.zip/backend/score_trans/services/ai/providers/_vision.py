from __future__ import annotations

from pathlib import Path
from typing import Any

from ....models.common.errors import AITranscriptionError
from ....utils.media import image_to_data_url
from ..core.config import AI_SYSTEM_MSG, AI_TEMPERATURE
from ..core.parsing import parse_vision_page_result
from ..core.prompts import _load_prompt_config, build_jianpu_prompt
from ..core.schemas import VisionPageResult
from ._http import chat_completions


MAX_VISION_TOKENS = 4096


class OpenAICompatibleVisionTranscriber:
    base_url: str
    model: str
    api_key: str
    timeout: float
    dry_run: bool
    extra_body: dict[str, Any] | None = None

    def transcribe_page(
        self,
        image_path: str | Path,
        *,
        target_key: str = "C",
        title: str | None = None,
        page_index: int = 0,
        extra_prompt: str | None = None,
    ) -> VisionPageResult:
        path = Path(image_path)
        if not path.is_file():
            raise FileNotFoundError(path)
        if not self.api_key and not self.dry_run:
            raise AITranscriptionError("AI API key not configured. Set it in Settings.")

        prompt = build_jianpu_prompt(
            target_key=target_key,
            title=title,
            page_index=page_index,
            extra_prompt=extra_prompt,
        )
        if self.dry_run:
            return VisionPageResult(
                title=title,
                key=target_key,
                meter="4/4",
                jianpu_text=f"title={title or 'AI 简谱'}\n1={target_key}\n4/4\n1 2 3 4 |",
                warnings=["dry_run: request was not sent"],
                confidence=1.0,
            )

        system_message = (
            _load_prompt_config().get("system_message")
            or AI_SYSTEM_MSG
            or "You are a careful sheet-music to numbered-notation transcription agent."
        )
        messages = [
            {"role": "system", "content": system_message},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": image_to_data_url(path)},
                    },
                ],
            },
        ]
        try:
            content = chat_completions(
                base_url=self.base_url,
                api_key=self.api_key,
                model=self.model,
                messages=messages,
                temperature=AI_TEMPERATURE,
                timeout=self.timeout,
                max_tokens=MAX_VISION_TOKENS,
                response_format={"type": "json_object"},
                extra_body=self.extra_body,
            )
        except Exception as exc:
            raise AITranscriptionError(
                f"AI transcription request failed: {exc}"
            ) from exc

        return parse_vision_page_result(content)
