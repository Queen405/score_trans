import { contextBridge, ipcRenderer } from 'electron'
import { electronAPI } from '@electron-toolkit/preload'

export interface BackendConnection {
  baseURL: string
  token: string
}

const api = {
  getBackendConnection: async (): Promise<BackendConnection> => {
    return await ipcRenderer.invoke('get-backend-connection') || {
      baseURL: 'http://127.0.0.1:19200',
      token: '',
    }
  },
  minimizeWindow: async (): Promise<void> => {
    await ipcRenderer.invoke('window:minimize')
  },
  toggleMaximizeWindow: async (): Promise<boolean> => {
    return ipcRenderer.invoke('window:toggle-maximize')
  },
  isMaximized: async (): Promise<boolean> => {
    return ipcRenderer.invoke('window:is-maximized')
  },
  closeWindow: async (): Promise<void> => {
    await ipcRenderer.invoke('window:close')
  },
  onMaximizedChanged: (callback: (maximized: boolean) => void): (() => void) => {
    const listener = (_event: unknown, maximized: boolean) => {
      callback(maximized)
    }
    ipcRenderer.on('window:maximized-changed', listener)
    return () => {
      ipcRenderer.removeListener('window:maximized-changed', listener)
    }
  },
  selectDirectory: async (): Promise<string | null> => {
    return ipcRenderer.invoke('dialog:select-directory')
  },
  getStoragePaths: async (): Promise<{ dataDir: string; cacheDir: string; configPath: string }> => {
    return ipcRenderer.invoke('storage:get')
  },
  setStoragePaths: async (paths: { dataDir?: string; cacheDir?: string }): Promise<{ dataDir: string; cacheDir: string; configPath: string }> => {
    return ipcRenderer.invoke('storage:set', paths)
  },
  relaunchApp: async (): Promise<void> => {
    await ipcRenderer.invoke('app:relaunch')
  },
  clearElectronCache: async (): Promise<void> => {
    await ipcRenderer.invoke('cache:clear-electron')
  },
  saveExportFile: async (
    source: { buffer: ArrayBuffer },
    dir: string,
    filename: string,
  ): Promise<string> => {
    return ipcRenderer.invoke('file:save-export', source, dir, filename)
  },
  openFolder: async (dir: string): Promise<void> => {
    await ipcRenderer.invoke('file:open-folder', dir)
  },
}

export type BackendAPI = typeof api

if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld('electron', electronAPI)
    contextBridge.exposeInMainWorld('api', api)
  } catch (error) {
    console.error(error)
  }
} else {
  window.electron = electronAPI
  window.api = api
}
